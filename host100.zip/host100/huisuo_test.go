package host100

// leetcode 46 全排列
//func permute(nums []int) [][]int {
//
//}
